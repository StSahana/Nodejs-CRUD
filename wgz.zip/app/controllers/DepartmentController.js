/**
 * Created by Administrator on 2016/7/7.
 */
var mongoose = require("mongoose");
var DepartmentModel = require("../models/DepartmentModel");

exports.departmentList = function (req, res) {

    DepartmentModel.find({}, function (err, departments) {
        if (err) {
            res.send({
                "statusCode": 500,
                "information": "Internal Server Error"
            });
        } else {
            res.send({
                "status": {
                    "statusCode": 200,
                    "information": "success"
                },
                "data": departments
            })
        }
        ;
    })
};

exports.findDepartmentByDid = function (req, res) {
    DepartmentModel.find({did: Number(req.params.did)}, function (err, users) {
        if (err) {
            res.send({
                "statusCode": 500,
                "information": "Internal Server Error"
            });
        }
        if (users) {
            res.send({
                "status": {
                    "statusCode": 200,
                    "information": "success"
                },
                "data": users
            });
        }
    });

};